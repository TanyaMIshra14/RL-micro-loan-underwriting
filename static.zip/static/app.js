const form = document.querySelector("#application-form");
const formMessage = document.querySelector("#form-message");
const resultPanel = document.querySelector("#result-panel");
const explanationPanel = document.querySelector("#explanation-panel");
const toast = document.querySelector("#toast");
const batchForm = document.querySelector("#batch-form");
const fileInput = document.querySelector("#csv-file");
const batchButton = document.querySelector("#batch-button");
const dropZone = document.querySelector("#drop-zone");
let toastTimeout;
let reportObjectUrl;

document.querySelector('input[name="disbursal_date"]').value = new Date().toISOString().slice(0, 10);

function showToast(message, isError = false) {
  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.add("visible");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove("visible"), 4200);
}

async function requestJson(url, options) {
  const response = await fetch(url, options);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload.detail || `Request failed (${response.status})`);
  }
  return payload;
}

function portfolioInputs() {
  return {
    portfolio_gnpa: Number(document.querySelector("#portfolio-gnpa").value),
    psl_share: Number(document.querySelector("#psl-share").value),
  };
}

function formPayload() {
  const data = Object.fromEntries(new FormData(form).entries());
  const numericFields = [
    "disbursed_amount", "asset_cost", "ltv", "cibil_score", "average_age_years",
    "average_age_months", "credit_history_years", "credit_history_months",
    "primary_active_accounts", "secondary_active_accounts", "primary_overdue_accounts",
    "secondary_overdue_accounts", "inquiries", "recent_delinquencies",
  ];
  for (const field of numericFields) data[field] = Number(data[field]);
  return { ...data, ...portfolioInputs() };
}

function formatScore(value) {
  return Number(value).toFixed(4);
}

function renderDecision(prediction) {
  const approved = prediction.decision === "APPROVE";
  const stamp = approved ? "APPROVE" : "DECLINE";
  const apr = prediction.proposed_apr_percent == null
    ? "Not applicable"
    : `${Number(prediction.proposed_apr_percent).toFixed(2)}%`;
  resultPanel.className = "result-panel";
  resultPanel.innerHTML = `
    <span class="section-index">MODEL OUTPUT · ${escapeHtml(prediction.application_id)}</span>
    <div class="decision-stamp ${approved ? "approve" : "decline"}"><span>POLICY RECOMMENDATION</span><b>${stamp}</b></div>
    <div class="result-metrics">
      <div class="result-metric"><span>Decline Q-score</span><b>${formatScore(prediction.decline_q_score)}</b></div>
      <div class="result-metric"><span>Approve Q-score</span><b>${formatScore(prediction.approve_q_score)}</b></div>
      <div class="result-metric"><span>Decision margin</span><b>${Number(prediction.decision_margin).toFixed(4)}</b></div>
      <div class="result-metric"><span>Proposed APR</span><b>${apr}</b></div>
    </div>
    <div class="empty-foot" style="margin-top:17px">Q-SCORES ARE NOT PROBABILITIES</div>`;
}

function renderFactors(factors, reportHtml) {
  const list = document.querySelector("#factor-list");
  list.replaceChildren();
  for (const factor of factors.slice(0, 8)) {
    const positive = factor.impact >= 0;
    const row = document.createElement("div");
    row.className = "factor-row";
    const dot = document.createElement("span");
    dot.className = `factor-dot ${positive ? "" : "negative"}`;
    const name = document.createElement("span");
    name.className = "factor-name";
    name.textContent = factor.feature;
    const impact = document.createElement("b");
    impact.className = `factor-value ${positive ? "positive" : "negative"}`;
    impact.textContent = `${factor.impact >= 0 ? "+" : ""}${Number(factor.impact).toFixed(4)}`;
    row.append(dot, name, impact);
    list.append(row);
  }
  const link = document.querySelector("#report-link");
    if (reportObjectUrl) URL.revokeObjectURL(reportObjectUrl);
    reportObjectUrl = URL.createObjectURL(new Blob([reportHtml], { type: "text/html" }));
    link.href = reportObjectUrl;
  explanationPanel.classList.remove("hidden");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;",
  })[char]);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  formMessage.textContent = "Scoring application and preparing explanation…";
  explanationPanel.classList.add("hidden");
  try {
    const application = formPayload();
    const prediction = await requestJson("/api/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(application),
    });
    renderDecision(prediction);
    const explanation = await requestJson("/api/explain", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(application),
    });
     renderFactors(explanation.factors, explanation.report_html);
    formMessage.textContent = "Assessment complete.";
  } catch (error) {
    formMessage.textContent = "Assessment could not be completed.";
    showToast(error.message, true);
  } finally {
    button.disabled = false;
  }
});

document.querySelectorAll(".nav-item").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach((item) => item.classList.remove("active"));
    document.querySelectorAll(".view").forEach((view) => view.classList.remove("active-view"));
    button.classList.add("active");
    document.querySelector(`#${button.dataset.view}`).classList.add("active-view");
  });
});

fileInput.addEventListener("change", () => {
  const file = fileInput.files[0];
  document.querySelector("#file-name").textContent = file ? file.name : "No file selected";
  batchButton.disabled = !file;
});

for (const eventName of ["dragenter", "dragover"]) {
  dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropZone.classList.add("dragover");
  });
}
for (const eventName of ["dragleave", "drop"]) {
  dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropZone.classList.remove("dragover");
  });
}
dropZone.addEventListener("drop", (event) => {
  const [file] = event.dataTransfer.files;
  if (!file) return;
  const transfer = new DataTransfer();
  transfer.items.add(file);
  fileInput.files = transfer.files;
  fileInput.dispatchEvent(new Event("change"));
});

batchForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const file = fileInput.files[0];
  if (!file) return;
  batchButton.disabled = true;
  document.querySelector("#batch-message").textContent = "Scoring uploaded rows…";
  const body = new FormData();
  body.append("file", file);
  const assumptions = portfolioInputs();
  const params = new URLSearchParams(assumptions);
  try {
    const result = await requestJson(`/api/predict-csv?${params}`, { method: "POST", body });
    renderBatch(result.predictions);
    document.querySelector("#batch-message").textContent = `${result.count.toLocaleString()} applications scored.`;
  } catch (error) {
    document.querySelector("#batch-message").textContent = "Batch scoring failed.";
    showToast(error.message, true);
  } finally {
    batchButton.disabled = false;
  }
});

function renderBatch(rows) {
  const panel = document.querySelector("#batch-results");
  panel.replaceChildren();
  const heading = document.createElement("h3");
  heading.textContent = "Scored applications";
  panel.append(heading);
  const table = document.createElement("table");
  table.className = "batch-table";
  const headers = ["Application", "Decision", "Decline Q", "Approve Q", "Margin", "Proposed APR"];
  const thead = document.createElement("thead");
  const headerRow = document.createElement("tr");
  headers.forEach((title) => {
    const th = document.createElement("th");
    th.textContent = title;
    headerRow.append(th);
  });
  thead.append(headerRow);
  const tbody = document.createElement("tbody");
  rows.forEach((row) => {
    const tr = document.createElement("tr");
    const values = [
      row.UNIQUEID,
      row.DECISION,
      formatScore(row.DECLINE_Q_SCORE),
      formatScore(row.APPROVE_Q_SCORE),
      Number(row.DECISION_MARGIN).toFixed(4),
      row.PROPOSED_APR_PERCENT == null ? "—" : `${Number(row.PROPOSED_APR_PERCENT).toFixed(2)}%`,
    ];
    values.forEach((value, index) => {
      const td = document.createElement("td");
      if (index === 1) {
        const badge = document.createElement("span");
        badge.className = `table-decision ${row.DECISION === "APPROVE" ? "approve" : "decline"}`;
        badge.textContent = value;
        td.append(badge);
      } else {
        td.textContent = value;
      }
      tr.append(td);
    });
    tbody.append(tr);
  });
  table.append(thead, tbody);
  panel.append(table);
  const download = document.createElement("a");
  download.className = "download-link";
  download.href = URL.createObjectURL(new Blob([JSON.stringify(rows, null, 2)], { type: "application/json" }));
  download.download = "underwriting_predictions.json";
  download.textContent = "Download results JSON ↗";
  panel.append(download);
  panel.classList.remove("hidden");
}

async function updateHealth() {
  const dot = document.querySelector("#health-dot");
  const label = document.querySelector("#health-label");
  try {
    const health = await requestJson("/api/health");
    dot.classList.toggle("online", health.model_loaded);
    dot.classList.toggle("offline", !health.model_loaded);
    label.textContent = health.model_loaded ? "Model ready" : "Model unavailable";
    if (!health.model_loaded) showToast(health.message || "Train a model before scoring.", true);
  } catch {
    dot.classList.add("offline");
    label.textContent = "API unavailable";
  }
}

updateHealth();